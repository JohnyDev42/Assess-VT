#include <linux/errno.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/cdev.h>

#include "scull.h"

/* triming the data. */
int scull_trim(struct scull_dev *d)
{
	struct scull_qset *dptr, *next;

	if (mutex_lock_interruptible(&d->sd_lock))
		return -ERESTARTSYS;

	for (dptr = d->sd_qset; dptr; dptr = next) {
		if (dptr->qs_data) {
			int i;

			for (i = 0; i < d->sd_qsetsiz; i++)
				if (dptr->qs_data[i])
					kfree(dptr->qs_data[i]);
			kfree(dptr->qs_data);
		}
		next = dptr->qs_next;
		kfree(dptr);
	}
	d->sd_qset = NULL;

	mutex_unlock(&d->sd_lock);

	return 0;
}
