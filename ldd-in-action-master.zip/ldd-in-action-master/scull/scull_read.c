#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/mutex.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>

#include "scull.h"
#include "scull_follow.h"
#include "scull_debug.h"

ssize_t scull_read(struct file *filp, char __user *buf, size_t len,
		   loff_t *f_pos)
{
	struct scull_dev *d = filp->private_data;
	struct scull_qset *dptr;
	int quantum;
	int qsetsiz;
	int itemsiz;
	int item, s_pos, q_pos, rest;
	ssize_t ret = 0;

	debug_scull_dev(d, __FUNCTION__, __LINE__);

	if (mutex_lock_interruptible(&d->sd_lock))
		return -ERESTARTSYS;

	quantum = d->sd_quantum;
	qsetsiz = d->sd_qsetsiz;
	itemsiz = quantum * qsetsiz;

	if (*f_pos >= d->sd_size)
		goto out;
	if (*f_pos + len > d->sd_size)
		len = d->sd_size - *f_pos;

	/* find listitem, qset index, and offset in the quantum */
	item = (long) *f_pos / itemsiz;
	rest = (long) *f_pos % itemsiz;
	s_pos = rest / quantum;
	q_pos = rest % quantum;

	/* follow the list up to the right position. */
	dptr = __scull_follow(d, item);
	if (IS_ERR(dptr)) {
		ret = PTR_ERR(dptr);
		goto out;
	} else if (!dptr->qs_data || !dptr->qs_data[s_pos])
		goto out;

	/* read only up to the end of this quantum. */
	if (len > quantum - q_pos)
		len = quantum - q_pos;

	if (copy_to_user(buf, dptr->qs_data[s_pos] + q_pos, len)) {
		ret = -EFAULT;
		goto out;
	}
	*f_pos += len;
	ret = len;
out:
	mutex_unlock(&d->sd_lock);
	return ret;
}
