#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/fs.h>

#include "scull.h"

/* Scull device manager. */
static struct scull scull = {
	.s_name =	SCULL_DEV_NAME,
	.s_nr_dev =	NR_SCULL_DEV,
	.s_cdevs =	LIST_HEAD_INIT(scull.s_cdevs),
};

static int __init init_scull(void)
{
	struct class *c;
	int ret;
	int i;

	/* allocate the scull device region. */
	ret = alloc_chrdev_region(&scull.s_dev, 0, scull.s_nr_dev, scull.s_name);
	if (ret != 0)
		return ret;

	/* create a scull device class in sysfs. */
	c = class_create(THIS_MODULE, scull.s_name);
	if (IS_ERR(c)) {
		cleanup_scull(&scull);
		return PTR_ERR(c);
	}
	scull.s_class = c;

	/* initialize the scull devices. */
	for (i = 0; i < NR_SCULL_DEV; i++) {
		ret = init_scull_dev(&scull, i);
		if (ret) {
			cleanup_scull(&scull);
			return ret;
		}
	}

	return 0;
}

static void __exit exit_scull(void)
{
	cleanup_scull(&scull);
}

module_init(init_scull);
module_exit(exit_scull);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Kei Nohguchi <mail@nohguchi.com>");
MODULE_DESCRIPTION("scull0-3 example");
