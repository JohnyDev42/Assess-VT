#ifndef _LDD_SCULL_WRITE_H
#define _LDD_SCULL_WRITE_H

ssize_t scull_write(struct file *, const char __user *buf, size_t len,
		    loff_t *offset);

#endif /* _LDD_SCULL_WRITE_H */
