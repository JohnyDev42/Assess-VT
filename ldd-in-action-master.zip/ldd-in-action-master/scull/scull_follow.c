#include <linux/err.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/cdev.h>

#include "scull.h"

struct scull_qset *__scull_follow(struct scull_dev *d, int item)
{
	struct scull_qset *prev = NULL, **dptr = &d->sd_qset;
	int i;

	/* go through the qset linked list to find an item. */
	for (i = 0; i <= item; i++) {
		if (!*dptr) {
			*dptr = kmalloc(sizeof(struct scull_qset), GFP_KERNEL);
			if (!*dptr)
				return ERR_PTR(-ENOMEM);
			memset(*dptr, 0, sizeof(struct scull_qset));
			if (prev)
				prev->qs_next = *dptr;
		}
		if (i == item)
			return *dptr;
		prev = *dptr;
		dptr = &((*dptr)->qs_next);
	}

	return NULL;
}
