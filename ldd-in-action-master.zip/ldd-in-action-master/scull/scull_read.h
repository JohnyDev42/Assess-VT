#ifndef _LDD_SCULL_READ_H
#define _LDD_SCULL_READ_H

ssize_t scull_read(struct file *, char __user *buf, size_t len,
		   loff_t *offset);

#endif /* _DD_SCULL_READ_H */
