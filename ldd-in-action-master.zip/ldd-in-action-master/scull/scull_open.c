#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/kernel.h>

#include "scull.h"
#include "scull_trim.h"
#include "scull_debug.h"

int scull_open(struct inode *inodp, struct file *filp)
{
	struct scull_dev *d = container_of(inodp->i_cdev, struct scull_dev, sd_cdev);

	debug_scull_dev(d, __FUNCTION__, __LINE__);

	/* store the scull_dev under file pointer. */
	filp->private_data = d;

	/* trim the data, if open was write-only. */
	if ((filp->f_flags & O_ACCMODE) == O_WRONLY) {
		scull_trim(d);
	}

	return 0;
}
