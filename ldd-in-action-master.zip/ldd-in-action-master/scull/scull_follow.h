#ifndef _LDD_SCULL_FOLLOW_H
#define _LDD_SCULL_FOLLOW_H

struct scull_qset *__scull_follow(struct scull_dev *, int item);

#endif /* _LDD_SCULL_FOLLOW_H */
