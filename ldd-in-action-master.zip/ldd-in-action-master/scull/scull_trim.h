#ifndef _LDD_SCULL_TRIM_H
#define _LDD_SCULL_TRIM_H

int scull_trim(struct scull_dev *d);

#endif /* _LDD_SCULL_TRIM_H */
