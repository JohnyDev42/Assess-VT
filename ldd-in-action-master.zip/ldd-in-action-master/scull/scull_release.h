#ifndef _LDD_SCULL_RELEASE_H
#define _LDD_SCULL_RELEASE_H

int scull_release(struct inode *, struct file *);

#endif /* _LDD_SCULL_RELEASE_H */
