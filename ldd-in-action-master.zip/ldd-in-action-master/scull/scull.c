#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/slab.h>

#include "scull.h"
#include "scull_open.h"
#include "scull_release.h"
#include "scull_read.h"
#include "scull_write.h"
#include "scull_trim.h"
#include "scull_debug.h"

/* Actual scull devices. */
static struct scull_dev devs[NR_SCULL_DEV];

static struct file_operations scull_ops = {
	.owner = THIS_MODULE,
	.open = scull_open,
	.release = scull_release,
	.read = scull_read,
	.write = scull_write,
};

int init_scull_dev(struct scull *s, int i)
{
	struct scull_dev *d;
	char nodename[64];
	int ret;

	if (i < 0 || i >= NR_SCULL_DEV)
		return -EINVAL;

	/* initialize the scull device. */
	d = &devs[i];
	mutex_init(&d->sd_lock);
	d->sd_dev = MKDEV(MAJOR(s->s_dev), MINOR(s->s_dev) + i);
	list_add(&d->sd_node, &s->s_cdevs);

	/* 8K, e.g. PAGE_SIZE, pset qset. */
	d->sd_qsetsiz = 512;
	d->sd_quantum = PAGE_SIZE / d->sd_qsetsiz;

	/* initialize the cdev with file_operations. */
	cdev_init(&d->sd_cdev, &scull_ops);
	d->sd_cdev.owner = THIS_MODULE;
	ret = cdev_add(&d->sd_cdev, d->sd_dev, 1);
	if (ret != 0)
		return ret;

	/* Create a device for the user space interaction. */
	sprintf(nodename, "%s%d", s->s_name, i);
	device_create(s->s_class, NULL, d->sd_dev, d, nodename);

	debug_scull_dev(d, __FUNCTION__, __LINE__);

	return 0;
}

static int reset_scull_dev(struct scull *s, struct scull_dev *d)
{
	int ret;

	debug_scull_dev(d, __FUNCTION__, __LINE__);

	/* trim the data. */
	ret = scull_trim(d);
	if (ret)
		return ret;

	/* Cleanup entries inside the filesystem subsystem. */
	device_destroy(s->s_class, d->sd_dev);
	cdev_del(&d->sd_cdev);

	return 0;
}

void cleanup_scull(struct scull *s)
{
	struct scull_dev *d;

	list_for_each_entry(d, &s->s_cdevs, sd_node)
		reset_scull_dev(s, d);

	if (s->s_class)
		class_destroy(s->s_class);
	if (s->s_dev)
		unregister_chrdev_region(s->s_dev, s->s_nr_dev);
}
