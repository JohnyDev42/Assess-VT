#include <linux/fs.h>
#include <linux/kernel.h>

int scull_release(struct inode *inodp, struct file *filp)
{
	pr_info("%s\n", __FUNCTION__);
	return 0;
}
