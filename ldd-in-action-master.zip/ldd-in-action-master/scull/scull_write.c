#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/types.h>
#include <linux/err.h>
#include <linux/errno.h>
#include <linux/mutex.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>

#include "scull.h"
#include "scull_follow.h"
#include "scull_debug.h"

ssize_t scull_write(struct file *filp, const char __user *buf, size_t len,
		    loff_t *f_pos)
{
	struct scull_dev *d = filp->private_data;
	struct scull_qset *dptr;
	int quantum = d->sd_quantum;
	int qsetsiz = d->sd_qsetsiz;
	int itemsiz = quantum * qsetsiz;
	int item, s_pos, q_pos, rest;
	ssize_t ret = -ENOMEM;

	debug_scull_dev(d, __FUNCTION__, __LINE__);

	if (mutex_lock_interruptible(&d->sd_lock))
		return -ERESTARTSYS;

	/* find the qset. */
	item = (long) *f_pos / itemsiz;
	rest = (long) *f_pos % itemsiz;
	s_pos = rest / quantum;
	q_pos = rest % quantum;

	/* find the qset. */
	dptr = __scull_follow(d, item);
	if (IS_ERR(dptr)) {
		ret = PTR_ERR(dptr);
		goto out;
	} else if (!dptr->qs_data) {
		dptr->qs_data = kmalloc(qsetsiz * sizeof(void *), GFP_KERNEL);
		if (!dptr->qs_data)
			goto out;
		memset(dptr->qs_data, 0, qsetsiz * sizeof(void *));
	}

	/* make sure quantum is there. */
	if (!dptr->qs_data[s_pos]) {
		dptr->qs_data[s_pos] = kmalloc(quantum, GFP_KERNEL);
		if (!dptr->qs_data[s_pos])
			goto out;
	}

	/* write only up to the end of this quantum. */
	if (len > quantum - q_pos)
		len = quantum - q_pos;

	if (copy_from_user(dptr->qs_data[s_pos] + q_pos, buf, len)) {
		ret = -EFAULT;
		goto out;
	}
	*f_pos += len;
	ret = len;

	/* update the size. */
	if (d->sd_size < *f_pos)
		d->sd_size = *f_pos;
out:
	mutex_unlock(&d->sd_lock);
	return ret;
}
