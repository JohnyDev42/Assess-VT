#ifndef _LDD_SCULL_H
#define _LDD_SCULL_H

#define SCULL_DEV_NAME	"scull"
#define NR_SCULL_DEV	4

struct scull {
	const char		*s_name;	/* prefix of device node */
	int			s_nr_dev;	/* number of device node */
	dev_t			s_dev;		/* base device number */
	struct class		*s_class;	/* device class in sysfs */
	struct list_head	s_cdevs;	/* cdevs */
};

struct scull_dev {
	dev_t			sd_dev;		/* device number */
	struct list_head	sd_node;	/* device list node */
	struct mutex		sd_lock;	/* device lock */
	struct cdev		sd_cdev;	/* actual cdev */
	struct scull_qset	*sd_qset;	/* quantum set */
	int			sd_qsetsiz;	/* size of quantum set */
	int			sd_quantum;	/* size of the quantum */
	loff_t			sd_size;	/* total size */
};

struct scull_qset {
	struct scull_qset	*qs_next;	/* singly linked-list qset */
	void			**qs_data;	/* actual data. */
};

int init_scull_dev(struct scull *d, int i);
void cleanup_scull(struct scull *s);

#endif /* _LDD_SCULL_H */
