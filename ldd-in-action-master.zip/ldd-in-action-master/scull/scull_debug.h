#ifndef _LDD_SCULL_PRINT_H
#define _LDD_SCULL_DEBUG_H

#include <linux/ratelimit.h>

static inline void debug_scull_dev(const struct scull_dev *d,
				   const char *func, int line)
{
	pr_info_ratelimited(KERN_INFO "%s:%d: %u:%u\n", func, line,
			    MAJOR(d->sd_dev), MINOR(d->sd_dev));
}

#endif /* _LDD_SCULL_DEBUG_H */
