# Linux Device Drivers in action

[![Build Status]](https://travis-ci.org/keinohguchi/ldd-in-action)

Our beloved [LDD] in action on the latest linux kernel.

Here is my linux kernel version in action.

```
air1$ uname -an
Linux air1 4.15.2.1 #1 SMP PREEMPT Sat Feb 10 08:01:10 PST 2018 x86_64 GNU/Linux
```

[Build Status]: https://travis-ci.org/keinohguchi/ldd-in-action.svg
[LDD]: https://lwn.net/Kernel/LDD3/

## Build

Top level `make` will do the work:

```
air1$ make
make -C /lib/modules/4.15.2.1/build M=/home/kei/git/ldd-in-action modules
make[1]: Entering directory '/home/kei/src/linux-4.15.2'
  CC [M]  /home/kei/git/ldd-in-action/current/current.o
  LD [M]  /home/kei/git/ldd-in-action/current/ldd_current.o
  CC [M]  /home/kei/git/ldd-in-action/nrcpus/nrcpus.o
  LD [M]  /home/kei/git/ldd-in-action/nrcpus/ldd_nrcpus.o
  Building modules, stage 2.
  MODPOST 2 modules
  CC      /home/kei/git/ldd-in-action/current/ldd_current.mod.o
  LD [M]  /home/kei/git/ldd-in-action/current/ldd_current.ko
  CC      /home/kei/git/ldd-in-action/nrcpus/ldd_nrcpus.mod.o
  LD [M]  /home/kei/git/ldd-in-action/nrcpus/ldd_nrcpus.ko
make[1]: Leaving directory '/home/kei/src/linux-4.15.2'
air1$
```

## Cleanup

Just `make clean`, of course:

```
air1$ make clean
make -C /lib/modules/4.15.2.1/build M=/home/kei/git/ldd-in-action clean
make[1]: Entering directory '/home/kei/src/linux-4.15.2'
  CLEAN   /home/kei/git/ldd-in-action/.tmp_versions
  CLEAN   /home/kei/git/ldd-in-action/Module.symvers
make[1]: Leaving directory '/home/kei/src/linux-4.15.2'
air1$
```

Happy Hackin!
