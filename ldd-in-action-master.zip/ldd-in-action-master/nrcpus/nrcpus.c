#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/smp.h>

static void print_cpus(const char *funcname)
{
	int cpu = get_cpu();
	pr_info("%s: NRCPUS=%d, %d=get_cpu()\n", funcname,
		NR_CPUS, cpu);
	put_cpu();
}

static int __init init_nrcpus(void)
{
	print_cpus(__FUNCTION__);
	return 0;
}

static void __exit exit_nrcpus(void)
{
	print_cpus(__FUNCTION__);
}

module_init(init_nrcpus);
module_exit(exit_nrcpus);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Kei Nohguchi <mail@nohguchi.com>");
MODULE_DESCRIPTION("NR_CPUS and get_cpu() example");
