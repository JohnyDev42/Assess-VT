#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>

static int __init init_current(void)
{
	pr_info("current->comm=%s, currend->pid=%d\n",
		current->comm, current->pid);
	return 0;
}

static void __exit exit_current(void)
{
	pr_info("%s: current->comm=%s, current->pid=%d\n",
		__FUNCTION__, current->comm, current->pid);
}

module_init(init_current);
module_exit(exit_current);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Kei Nohguchi <mail@nohguchi.com>");
MODULE_DESCRIPTION("current example");
